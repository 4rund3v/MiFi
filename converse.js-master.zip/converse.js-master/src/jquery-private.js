/*global define */
define(['jquery'], function (jq) {
    return jq.noConflict( true );
});

/*global define */
define('underscore', ['lodash'], function (_) {
    return _;
});

define("transcripts", [
    "tpl!converse-logs/double_logins",
], function () {
    return arguments;
});
